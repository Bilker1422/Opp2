import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        window w = new window();
        w.setSize(170,220);
        w.setVisible(true);
        w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        w.setLocationRelativeTo(null);
    }
}